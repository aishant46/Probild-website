import { contacts, projects, services, team, bookings, feedback, type Feedback, type InsertFeedback } from "@shared/schema";
import type { 
  Contact, InsertContact,
  Project, InsertProject,
  Service, InsertService,
  Team, InsertTeam,
  Booking, InsertBooking
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lt } from "drizzle-orm";

export interface IStorage {
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;

  createProject(project: InsertProject): Promise<Project>;
  getProjects(): Promise<Project[]>;

  createService(service: InsertService): Promise<Service>;
  getServices(): Promise<Service[]>;

  createTeam(member: InsertTeam): Promise<Team>;
  getTeam(): Promise<Team[]>;

  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookings(): Promise<Booking[]>;
  getBookingsByDate(date: Date): Promise<Booking[]>;
  updateBookingStatus(id: number, status: string): Promise<Booking>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  getFeedback(): Promise<Feedback[]>;
}

export class DatabaseStorage implements IStorage {
  async createContact(contact: InsertContact): Promise<Contact> {
    const [result] = await db.insert(contacts).values(contact).returning();
    return result;
  }

  async getContacts(): Promise<Contact[]> {
    return await db.select().from(contacts);
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [result] = await db.insert(projects).values(project).returning();
    return result;
  }

  async getProjects(): Promise<Project[]> {
    return await db.select().from(projects);
  }

  async createService(service: InsertService): Promise<Service> {
    const [result] = await db.insert(services).values(service).returning();
    return result;
  }

  async getServices(): Promise<Service[]> {
    return await db.select().from(services);
  }

  async createTeam(member: InsertTeam): Promise<Team> {
    const [result] = await db.insert(team).values(member).returning();
    return result;
  }

  async getTeam(): Promise<Team[]> {
    return await db.select().from(team);
  }

  async createBooking(booking: InsertBooking): Promise<Booking> {
    const [result] = await db.insert(bookings).values(booking).returning();
    return result;
  }

  async getBookings(): Promise<Booking[]> {
    return await db.select().from(bookings).orderBy(bookings.date, bookings.time);
  }

  async getBookingsByDate(date: Date): Promise<Booking[]> {
    const startDate = new Date(date);
    startDate.setHours(0, 0, 0, 0);

    const endDate = new Date(date);
    endDate.setHours(23, 59, 59, 999);

    return await db
      .select()
      .from(bookings)
      .where(
        and(
          gte(bookings.date, startDate),
          lt(bookings.date, endDate)
        )
      )
      .orderBy(bookings.time);
  }

  async updateBookingStatus(id: number, status: string): Promise<Booking> {
    const [result] = await db
      .update(bookings)
      .set({ status })
      .where(eq(bookings.id, id))
      .returning();
    return result;
  }
  async createFeedback(feedbackData: InsertFeedback): Promise<Feedback> {
    const [result] = await db.insert(feedback).values(feedbackData).returning();
    return result;
  }

  async getFeedback(): Promise<Feedback[]> {
    return await db.select().from(feedback).orderBy(feedback.createdAt);
  }
}

export const storage = new DatabaseStorage();