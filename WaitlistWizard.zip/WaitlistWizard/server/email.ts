import nodemailer from "nodemailer";
import type { Booking } from "@shared/schema";

// Create email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export async function sendBookingConfirmation(booking: Booking) {
  const bookingDate = new Date(booking.date);

  const emailContent = `
    <h1>Booking Confirmation</h1>
    <p>Dear ${booking.clientName},</p>
    <p>Thank you for booking a consultation with PixelPerfect Studio. Here are your booking details:</p>
    <ul>
      <li><strong>Service:</strong> ${booking.serviceType}</li>
      <li><strong>Date:</strong> ${bookingDate.toLocaleDateString()}</li>
      <li><strong>Time:</strong> ${booking.time}</li>
    </ul>
    <p>If you need to make any changes to your booking, please contact us.</p>
    <p>Best regards,<br>PixelPerfect Studio Team</p>
  `;

  await transporter.sendMail({
    from: process.env.SMTP_USER,
    to: booking.clientEmail,
    subject: "Your PixelPerfect Studio Booking Confirmation",
    html: emailContent,
  });
}